import React from 'react';
import {Link} from 'react-router-dom';

export const Tag = (props) => {
    //if we need to add additional properties to the style, we use ...props.add
    const template = <div
        style={{
            background: props.bck,
            fontSize: props.size,
            color: props.color,
            padding: '5px 10px',
            display: 'inline-block',
            fontFamily: 'Righteous',
            ...props.add
        }}
    >{props.children}</div>

    if (props.link){
        return(
            <Link to={props.linkTo}>
                {template}
            </Link>
        )
    }else{
        return template
    }
}

//to make array of datas as frebase would not provide the array
export const firebaseLooper = (snapshot) => {
    const data = [];
    snapshot.forEach((childSnapshot)=>{
        data.push({
            ...childSnapshot.val(),
            id: childSnapshot.key
        })
    });
    return data;
} 

//since results appears as first one goes to the last and last one goes to the first
export const reverseArray =(actualArray) => {
    let reversedArray = [];
    for(let i=actualArray.length-1;i>=0;i--){
        reversedArray.push(actualArray[i]);
    }
    return reversedArray;
} 

export const validate = (element) => {
    let error = [true, ''];

    if(element.validation.email){
        const valid = /\S+@\S+\.\S+/.test(element.value);
        const message = `${!valid ? 'Must be a valid email': ''}`;
        error= !valid ? [valid, message] : error;
    }

    if(element.validation.required){
        const valid = element.value.trim() !== "";
        const message = `${!valid ? 'This field is required': ''}`;
        error= !valid ? [valid, message] : error;
    }

    return error;
}