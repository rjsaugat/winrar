import React, { Component } from 'react';

class Gallery extends Component {
    render() {
        return (
            <div className="gallery-container" style={{height: "1150px"}}>
                <div className="container">
                    <div className="row">
                        <h3>Gallery</h3>
                    </div>    
                </div>
            </div>
        );
    }
}

export default Gallery;